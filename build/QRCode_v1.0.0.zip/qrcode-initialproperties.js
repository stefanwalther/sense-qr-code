/*global define*/
define( [], function () {
    'use strict';
    return {
    };
} );
